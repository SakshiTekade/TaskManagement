INSERT INTO users (username, password) VALUES ('admin', '$2a$10$123456789012345678901234567890123456789012345678901234');  -- 'admin' password hashed
